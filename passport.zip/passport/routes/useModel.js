const mongoose=require("../server");

const userSchema=new mongoose.Schema(
{
    email:String,
    password:String
})

module.exports=mongoose.model('user',userSchema);
