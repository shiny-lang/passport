const express = require('express')
const profileRouter = express.Router()
const passport=require('passport')

const authenticate=(req)=>{
    if(req.user)
    return true
    else
    return false
}

profileRouter.route('/')
.get((req,res)=>{
    if(authenticate(req))
    res.send('welcome to your profile sai')
    else
    res.send('you need to be authenticated first')
   })
 
  


module.exports=profileRouter
