const express = require('express')
const loginRouter = express.Router()
const passport=require("passport")
const mongoose=require("../server");

const user=require("./useModel")
loginRouter.route('/')
.post(passport.authenticate('local'),(req,res)=>{
    res.send("you are logged in")
   
})

module.exports=loginRouter