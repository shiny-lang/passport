const express = require('express')
const registerRouter = express.Router()
const mongoose=require("../server");
const user=require("./useModel")
registerRouter.route('/')
.post((req,res)=>{
const record=new user(
    {
        email:req.body.username,
        password:req.body.password
    })
    record.save()
    .then((data)=>{res.send("you have registered")})
    .catch((err=>console.log(err)))

})
.get((req,res)=>{
    res.send("get is not allowed on register end point")
});
module.exports=registerRouter