const LocalStrategy=require('passport-local')
const users=require('./routes/useModel')
const authenticationUser=(username,password,done)=>
{
    users.findOne({email:username})
        .then((user)=>{
        if(user.password===password)
        {
            done(null,user)
        }
        else

        {
            done(null,false)
        }
    })
    .catch((err)=>{done(err)})
}
const start=(passport)=>
    {
    passport.use(new LocalStrategy(authenticationUser))
    passport.serializeUser((user,done)=>
    {   if(user)
        done(null,user.id)
    })
    passport.deserializeUser((id,done)=>{
     users.findById(id)
            .then((user)=>
            {
                if(user)
                done(null,user)
            })
        })
    }
module.exports=start